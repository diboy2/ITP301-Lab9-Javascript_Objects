var image = {
  topPosition:'100px',
  leftPosition:'100px',

  updatePosition: function(){
    $('#img-table').css('left', this.leftPosition);
    $('#img-table').css('top', this.topPosition);
  }
};